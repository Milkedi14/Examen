function datos(){
    let correo = document.getElementById("correo").value;
    let Nombre = document.getElementById("Nombre").value; 
    let Apellido = document.getElementById("Apellido").value;
    let edad = document.getElementById("edad").value; 
    let Direcciòn = document.getElementById("Direcciòn").value; 
    let telefono = document.getElementById("telefono").value;
    let regiòn = document.getElementById("regiòn").value;
    let cantidad = document.getElementById("cantidad").value;
    let precio = document.getElementById("precio").value;
    
    
    var jubilado = prompt("¿Es jubilado?\n Para confirmar escriba el número \n 1. Si \n 2. No");
    if(jubilado == 1){
      let Montogravado= parseFloat(precio*cantidad);
      let descuento= parseFloat(Montogravado*15/100);
      let total= parseFloat(Montogravado-descuento);
        document.write("Correo="+correo +"<br>");
        document.write("Nombre="+Nombre +Apellido+"<br>");
        document.write("Dirección="+Direcciòn +"<br>");
        document.write("Número telefónico="+telefono +"<br>");
        document.write("Región="+regiòn +"<br>");
        document.write("cantidad="+cantidad +"<br>");
        document.write("Total importe="+ parseFloat (precio*cantidad )+"<br>");
        document.write("Descuento="+descuento+"<br>");
        document.write("Monto gravado="+ Montogravado +"<br>");
        document.write("Total ="+ total +"<br>");
      
    }
    if(jubilado == 2){
      
        let Montogravado= parseFloat(precio*cantidad);
        let Totalimpuesto= parseFloat(Montogravado*7/100);
        let total= parseFloat (Montogravado+Totalimpuesto);
      
        document.write("Correo="+correo +"<br>");
        document.write("Nombre="+Nombre +Apellido+"<br>");
        document.write("Dirección="+Direcciòn +"<br>");
        document.write("Número telefónico="+telefono +"<br>");
        document.write("Región="+regiòn +"<br>");
        document.write("cantidad="+cantidad +"<br>");
        document.write("Total importe="+ parseFloat (precio*cantidad )+"<br>");
        document.write("Monto gravado="+ Montogravado +"<br>");
        document.write("Total impuesto="+ Totalimpuesto  +"<br>");
        document.write("Total ="+total +"<br>");
      
    }
  }